This archive contains the additional projects included in the v15 Official Source.

They have no modifications (besides size reductions) and I, Cuvvvie, will not support them.

These are just included for those who want them.

Good luck!

- Accumulator
- Launcher
- Monitor
- MonitorTerminal
- Updater
- WorldDialog